# Burger Syauqi POS — Android Bluetooth Printer Starter

Starter project Android native (Kotlin) untuk uji koneksi Bluetooth Classic SPP dan cetak struk ESC/POS ke printer RPP02N 58 mm.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `BurgerSyauqiAndroid` dari Android Studio.
3. Tunggu Gradle Sync selesai.
4. Jalankan ke perangkat Android (USB debugging) atau build APK melalui Build > Build APK(s).

## Cara tes printer
1. Nyalakan RPP02N dan masukkan kertas thermal 58 mm.
2. Pair melalui Setelan Android > Bluetooth. PIN berbeda antar unit/firmware; 0000 atau 1234 umum ditemukan, ikuti manual/label unit.
3. Buka aplikasi, muat ulang perangkat paired, pilih printer.
4. Hubungkan, lalu tekan Tes cetak struk.

## Catatan teknis
- Menggunakan Bluetooth Classic RFCOMM SPP UUID `00001101-0000-1000-8000-00805F9B34FB`.
- Mengirim byte ESC/POS secara langsung.
- Contoh ini adalah modul uji printer terpisah, belum terhubung ke katalog, database, transaksi, atau laporan POS lengkap.
- Beberapa varian RPP02N bisa berbeda pada antarmuka Bluetooth (Classic SPP/BLE). Jika pairing tidak muncul atau koneksi gagal, periksa mode/varian unit dan gunakan SDK resmi yang sesuai.
- Perintah cutter bersifat opsional; RPP02N mini umumnya tidak memiliki pemotong otomatis.
- Untuk produksi: tambahkan database lokal Room, backup/ekspor, pemulihan koneksi, antrean cetak, dan integrasi transaksi.

## Build APK otomatis (tanpa Android Studio)
Project ini menyertakan workflow GitHub Actions di `.github/workflows/build-apk.yml`.
1. Upload seluruh isi folder project ke repository GitHub baru.
2. Buka tab **Actions** dan jalankan **Build Burger Syauqi APK** (atau push ke branch `main`).
3. Setelah status workflow hijau, buka hasil run dan unduh artifact **Burger-Syauqi-debug-apk**.
4. Ekstrak artifact, lalu pasang `app-debug.apk` di Android. Android mungkin meminta izin memasang aplikasi dari sumber tersebut.

Catatan: workflow ini hanya mengompilasi aplikasi starter uji printer yang ada saat ini. Ini belum merupakan aplikasi kasir lengkap.
