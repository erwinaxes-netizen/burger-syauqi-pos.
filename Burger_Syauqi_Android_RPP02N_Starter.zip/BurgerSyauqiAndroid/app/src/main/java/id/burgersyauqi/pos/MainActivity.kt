package id.burgersyauqi.pos

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var selected: BluetoothDevice? = null
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var connectButton: Button
    private var pairedDevices: List<BluetoothDevice> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBluetoothPermissionIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 24)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        root.addView(TextView(this).apply {
            text = "🍔 BURGER SYAUQI POS"
            textSize = 24f
            setTextColor(0xFF20252D.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Integrasi printer Bluetooth RPP02N • 58 mm"
            textSize = 14f
            setPadding(0, 8, 0, 22)
        })
        status = TextView(this).apply {
            text = "Status: Belum terhubung"
            textSize = 15f
            setPadding(0, 8, 0, 18)
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "Pilih printer dari perangkat yang sudah dipasangkan di Android:"
            textSize = 14f
        })
        deviceSpinner = Spinner(this)
        root.addView(deviceSpinner)

        val refresh = Button(this).apply {
            text = "Muat ulang perangkat paired"
            setOnClickListener { loadPairedDevices() }
        }
        root.addView(refresh)

        connectButton = Button(this).apply {
            text = "Hubungkan printer"
            setOnClickListener { connectPrinter() }
        }
        root.addView(connectButton)

        root.addView(Button(this).apply {
            text = "Tes cetak struk"
            setOnClickListener { printTestReceipt() }
        })
        root.addView(Button(this).apply {
            text = "Putuskan koneksi"
            setOnClickListener { disconnectPrinter() }
        })
        root.addView(TextView(this).apply {
            text = "\nCatatan: lakukan pairing RPP02N terlebih dahulu melalui Setelan > Bluetooth. PIN yang umum dipakai adalah 0000 atau 1234; ikuti label/manual printer jika berbeda."
            textSize = 12f
        })
        setContentView(root)
        loadPairedDevices()
    }

    private fun hasConnectPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasConnectPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 41)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadPairedDevices()
        else status.text = "Izin Bluetooth diperlukan untuk memilih printer."
    }

    @Suppress("MissingPermission")
    private fun loadPairedDevices() {
        if (!hasConnectPermission()) {
            requestBluetoothPermissionIfNeeded()
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            status.text = "Bluetooth tidak tersedia pada perangkat ini."
            return
        }
        if (!adapter.isEnabled) {
            status.text = "Aktifkan Bluetooth Android terlebih dahulu."
            return
        }
        pairedDevices = adapter.bondedDevices?.sortedBy { it.name ?: it.address } ?: emptyList()
        val labels = pairedDevices.map { "${it.name ?: "Printer"} (${it.address})" }
        deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        status.text = if (labels.isEmpty()) "Belum ada perangkat paired. Pair RPP02N melalui Setelan Bluetooth." else "Ditemukan ${labels.size} perangkat paired."
    }

    @Suppress("MissingPermission")
    private fun connectPrinter() {
        if (!hasConnectPermission()) { requestBluetoothPermissionIfNeeded(); return }
        if (pairedDevices.isEmpty()) { loadPairedDevices(); return }
        selected = pairedDevices.getOrNull(deviceSpinner.selectedItemPosition)
        val device = selected ?: return
        status.text = "Menghubungkan ke ${device.name ?: "printer"}..."
        thread {
            try {
                socket?.close()
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                runOnUiThread { status.text = "Terhubung: ${device.name ?: device.address}" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal terhubung: ${e.message ?: "Periksa pairing dan mode printer"}" }
            }
        }
    }

    private fun disconnectPrinter() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        status.text = "Status: Terputus"
    }

    private fun printTestReceipt() {
        val s = socket
        if (s == null || !s.isConnected) {
            status.text = "Printer belum terhubung."
            return
        }
        status.text = "Mengirim tes cetak..."
        thread {
            try {
                val out: OutputStream = s.outputStream
                out.write(testReceiptBytes())
                out.flush()
                runOnUiThread { status.text = "Perintah tes cetak berhasil dikirim." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal mencetak: ${e.message}" }
            }
        }
    }

    // ESC/POS: initialize, center/bold heading, left-aligned sample receipt, feed paper.
    private fun testReceiptBytes(): ByteArray {
        val bytes = ArrayList<Byte>()
        fun add(vararg values: Int) { values.forEach { bytes.add(it.toByte()) } }
        fun text(value: String) { value.toByteArray(Charsets.US_ASCII).forEach { bytes.add(it) } }

        add(0x1B, 0x40)             // ESC @ initialize
        add(0x1B, 0x61, 0x01)       // center
        add(0x1B, 0x45, 0x01)       // bold on
        text("BURGER SYAUQI\n")
        add(0x1B, 0x45, 0x00)       // bold off
        text("TES PRINTER RPP02N\n")
        text("Kertas 58 mm / ESC-POS\n")
        add(0x1B, 0x61, 0x00)       // left
        text("--------------------------------\n")
        text("Burger Original       Rp 20.000\n")
        text("Cheese Burger         Rp 25.000\n")
        text("--------------------------------\n")
        add(0x1B, 0x45, 0x01)
        text("TOTAL                 Rp 45.000\n")
        add(0x1B, 0x45, 0x00)
        text("--------------------------------\n")
        add(0x1B, 0x61, 0x01)
        text("Terima kasih!\n")
        text("Selamat menikmati\n\n\n")
        add(0x1D, 0x56, 0x42, 0x00) // cut command; ignored by models without cutter
        return bytes.toByteArray()
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
